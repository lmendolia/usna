/*
	Name: LCDR C. W. Hoffmeister
	Alpha: 00tamu
	Course: SY204 - Sys Prgm & OS Fund
	Meeting: Dynamic Memory
	
	Description: pointerArray-02.c - Pointer Arithmetic
*/

// Required Includes
// Previous Uses
#include <stdio.h>  // Standard I/O Library: printf(3)

// Global Constants

// Function Prototypes

// main Function
int main( int argc, char *argv[] ) {
	// Declare Required Variables
	int intReturn = 0;  // Return variable, assume normal exit
	int intI = 0;       // Loop control
	int iarNums[5] = { 10, 20, 30, 40, 50 };  // Initialized array of ints
	int *iptNum;        // Pointer to int
	// Perform Function
	iptNum = iarNums + 1;  // Pointer Arithmetic - Shift memory location by multiple of size of data type pointing to (int 4 bytes in memory)
	*iptNum = 5;
	
	while ( intI < 5 ) {
		printf("iarNums[%d]: %d\n", intI, iarNums[intI]);
		intI++;
	}
	
	// varArray[N] syntax is equivalent to *( varArray + N )
	intI = 0;
	while ( intI < 5 ) {
		printf("iarNums[%d]: %d\n", intI, *(iarNums + intI));
		intI++;
	}
	
	// Return to Caller
	return intReturn;
}
