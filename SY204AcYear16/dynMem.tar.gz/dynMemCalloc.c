/*
	Name: LCDR C. W. Hoffmeister
	Alpha: 00tamu
	Course: SY204 - Sys Prgm & OS Fund
	Meeting: Dynamic Memory
	
	Description: dynMemCalloc.c - Dynamic memory allocation using calloc
*/

// Required includes
// Previous Uses
#include <stdio.h>   // Standard I/O Library: printf(3)
// New Uses
#include <stdlib.h>  // Standard Library: calloc(3), free(3)

// Global Constants

// Function Prototypes

// main Function
int main( int argc, char *argv[] ) {
	// Declare Required Variables
	int intReturn = 0;  // Return variable, assume normal exit
	int intI;           // Loop control
	int *iarNums;       // Array of ints
	// Perform function
	
	iarNums = calloc(5, sizeof( int ));
	
	intI = 0;
	while ( intI < 5 ) {
		iarNums[intI] = intI * intI;
		intI++;
	}
	
	intI = 0;
	while ( intI < 5 ) {
		printf("iarNums[%d]: %d\n", intI, iarNums[intI]);
		intI++;
	}
	
	free(iarNums);  // Call free to properly manage memory usage
	// Return to Caller
	return intReturn;
}
