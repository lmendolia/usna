/*
	Name: LCDR C. W. Hoffmeister
	Alpha: 00tamu
	Course: SY204 - Sys Prgm & OS Fund
	Meeting: Dynamic Memory
	
	Description: dynMemMalloc.c - Dynamic memory allocation using malloc
*/

// Required Includes
// Previous Uses
#include <errno.h>   // Error Number Library: E*
#include <stdio.h>   // Standard I/O Library: printf(3)
//New Uses
#include <stdlib.h>  // Standard Library: malloc(3), free(3)

// Global Constants

// Function Prototypes

// main Function
int main( int argc, char *argv[] ) {
	// Declare Required Variables
	int intReturn = 0;        // Return variable, assume normal exit
	int intI = 0;             // Loop control
	int *iarNums = NULL;      // Array of ints
	int *iptNumValue = NULL;  // Pointer to int
	// Perform Function
	iptNumValue = malloc(sizeof( int ));  // Allocate sizeof(int) bytes in the heap
	if ( iptNumValue == NULL )  exit(ENOMEM);
	
	*iptNumValue = 2017;
	
	printf("iptNumValue: %d\n", *iptNumValue);
	
	// Stu Act: malloc me
	// 1. Add code to allocate enough memory using malloc for an array of 5 ints
	// iarNums = malloc( ... );
	
	while ( intI < 5 ) {
		// Stu Act: malloc me
		// 2. When ready, uncomment line below and printf below
		//iarNums[intI] = intI * intI;
		intI++;
	}
	
	intI = 0;
	while ( intI < 5 ) {
		//printf("iarNums[%d]: %d\n", intI, iarNums[intI]);
		intI++;
	}
	
	free(iptNumValue);  // Call free to properly manage memory usage
	free(iarNums);
	// Return to Caller
	return intReturn;
}
