/*
	Name: LCDR C. W. Hoffmeister
	Alpha: 00tamu
	Course: SY204 - Sys Prgm & OS Fund
	Meeting: Dynamic Memory
	
	Description: dblPoint.c - Use of double pointers to solve single pointer set/unset issue.
	
	Usage: dblPoint <numElements> <realNameElem1> ... [realNameElemN]
*/

// Required Includes
// Previous Uses
#include <stdio.h>   // Standard I/O Library: printf(3)
#include <stdlib.h>  // Standard LIbrary: atoi(3), calloc(3), free(3), malloc(3)
#include <string.h>  // String Library: strdup(3)

// Type Defines
typedef struct {
	int YG;
	char company;
	char *firstName;
	char *lastName;
	char *realName;
	char major[4];
} cyber_oper;

// Global Constants

// Function Prototypes
cyber_oper **newCyberOpers(int numCyberOpers);
int addCyberOper(cyber_oper **aryCyberOpers, int maxNumCyberOpers, char *cyberOperRealName);
int printCyberOpers(cyber_oper **aryCyberOpers);
int freeCyberOpers(cyber_oper **aryCyberOpers);

// main Function
int main( int argc, char *argv[] ) {
	// Declare Required Variables
	int intReturn = 0;        // Return variable, assume normal exit
	int i;                    // Loop control
	int numCyberOpers = atoi(argv[1]);
	cyber_oper **someHaxors;  // Array of cyber operators
	// Perform Function
	someHaxors = newCyberOpers(numCyberOpers);  // Setup memory for someHaxors
	// atoi: ASCII to int, translate ASCII string to int
	
	printCyberOpers(someHaxors);  // List someHaxors; haven't added any therefore no output
	
	i = 2;
	while ( i < argc ) {  // Add in each Haxor
		addCyberOper(someHaxors, numCyberOpers, argv[i]);
		i++;
	}
	
	printCyberOpers(someHaxors);  // List someHaxors
	
	freeCyberOpers(someHaxors);  // Clean up memory
	// Return to Caller
	return intReturn;
}

// Setup dynamic memory for new array of numCyberOpers elements of type cyber_oper
cyber_oper **newCyberOpers(int numCyberOpers) {
	// Declare Required Variables
	cyber_oper **newCyberOper;
	// Perform Function
	newCyberOper = calloc( numCyberOpers + 1, sizeof( cyber_oper *));  // Need memory of NULL cyber_oper (NULL terminated array same concept as '\0' for string)
	return newCyberOper;
}

// Add a cyber_oper element to aryCyberOpers, not to exceed previously allocated memory
int addCyberOper(cyber_oper **aryCyberOpers, int maxNumCyberOpers, char *realNameCyberOper) {
	// Declare Required Variables
	int i = 0;  // Loop control
	// Perform Function
	while ( i < maxNumCyberOpers ) {
		if ( aryCyberOpers[i] == NULL ) {  // Array element unused
			aryCyberOpers[i] = malloc( sizeof( cyber_oper ) );
			aryCyberOpers[i]->realName = strdup(realNameCyberOper);
			return 0;
		}
		i++;
	}
	return 1;
}

// Prints the realNames of aryCyberOpers
int printCyberOpers(cyber_oper **aryCyberOpers) {
	// Declare Required Variables
	int intI = 0;  // Loop control
	cyber_oper *cybPrint = aryCyberOpers[intI];
	// Perform Function
	while ( cybPrint != NULL ) {
		printf("%s\n", cybPrint->realName);
		cybPrint = aryCyberOpers[++intI];
	}
	return 0;
}

// Free dynamic memory previously allocated to aryCyberOpers
int freeCyberOpers(cyber_oper **aryCyberOpers) {
	// Declare Required Variables
	// Perform Function
	
	// Stu Act: Manage Cyber Opers (it's a tough job, but someone has to do it)
	// 1. Correctly free memory allocated for elements in aryCyberOpers before freeing the aryCyberOpers
	
	
	free(aryCyberOpers);
	return 0;
}
