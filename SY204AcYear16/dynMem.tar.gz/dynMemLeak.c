/*
	Name: LCDR C. W. Hoffmeister
	Alpha: 00tamu
	Course: SY204 - Sys Prgm & OS Fund
	Meeting: Dynamic Memory
	
	Description: dynMemLeak.c - Example of a memory leak
*/

// Required Includes
// Previous Uses
#include <stdio.h>   // Standard I/O Library: printf(3)
#include <stdlib.h>  // Standard Library: malloc(3), free(3)

// Global Constants

// Function Prototypes

// main Function
int main( int argc, char *argv[] ) {
	// Declare Required Variables
	int intReturn = 0;  // Return variable, assume normal exit
	int *iptP;          // Pointer to int
	// Perform Function
	iptP = malloc(sizeof( int ));
	*iptP = 5;
	printf("iptP-%p: %d\n", iptP, *iptP);
	
	// Change where iptP is pointing to without freeing allocated memory first, memory leaked (4 bytes)
	
	// Stu Act: free me
	// 1. Free the memory pointed to by iptP before allocating new memory
	
	iptP = malloc(sizeof( int ));
	*iptP = 5;
	printf("iptP-%p: %d\n", iptP, *iptP);
	
	free(iptP);
	// Return to Caller
	return intReturn;
}
